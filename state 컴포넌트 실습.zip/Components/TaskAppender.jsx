import { useState } from "react";

export default function TaskAppender({ onSaveHandler }) {
  const [task, setTask] = useState();
  const [dueDate, setDueDate] = useState();
  const [priority, setPriority] = useState();

  const onTaskKeyUpHandler = (event) => {
    setTask(event.currentTarget.value);
  };
  const onDueDateChangeHandler = (event) => {
    setDueDate(event.currentTarget.value);
  };
  const onPrioritySelectHandler = (event) => {
    setPriority(event.currentTarget.value);
  };

  const onSaveClickHandler = () => {
    /**
     * App.js
     *  - taskList (state)
     *      - [ {...}, {...}, {...} ] + { ... }
     *      - [ {...}, {...}, {...}, {...} ]
     *  - onSaveHandler ==> App.js > setTaskList();
     */
    onSaveHandler((prevTaskList) => {
      // prevTaskList 배열을 복사해서 새로운 배열로 생성.
      const newTaskList = [...prevTaskList];
      // 새로운 배열에 새로운 객체를 push
      newTaskList.push({
        id: prevTaskList.length + 1,
        task,
        dueDate,
        priority,
        done: false,
      });

      return newTaskList;
    });
  };

  // Save를 클릭하면 동작할 함수.
  const onButtonClickHandler = () => {
    alert("Todo 추가");
  };

  // Task를 입력하면 동작할 함수.
  const onTodoInputKeyUpHandler = (event) => {
    console.log(event.currentTarget.value);
  };

  // 우선 순위를 변경하면 동작할 함수
  const onPriorityChangeHandler = (event) => {
    alert(event.currentTarget.value);
  };

  return (
    <footer>
      <input type="text" placeholder="Task" onKeyUp={onTaskKeyUpHandler} />
      <input type="date" onChange={onDueDateChangeHandler} />
      <select onChange={onPrioritySelectHandler}>
        <option>우선순위</option>
        <option value="1">높음</option>
        <option value="2">보통</option>
        <option value="3">낮음</option>
      </select>
      <button type="button" onClick={onSaveClickHandler}>
        Save
      </button>
    </footer>
  );
}
