export default function TaskList({ children }) {
  return <ul className="tasks">{children}</ul>;
}
