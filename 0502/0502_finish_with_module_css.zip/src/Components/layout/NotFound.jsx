import HeaderNav from "./HeaderNav";

const NotFound = () => {
  return (
    <div className="main-container">
      <HeaderNav />
      <div className="wrapper">페이지를 찾을 수 없습니다.</div>
    </div>
  );
};
export default NotFound;
