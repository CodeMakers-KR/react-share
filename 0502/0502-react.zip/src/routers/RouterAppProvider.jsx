import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Main from "../Components/main/Main";
import TaskMain from "../Components/tasks/TaskMain";
import MainLayout from "../Components/layout/MainLayout";

const RouterAppProvider = () => {
  const routers = createBrowserRouter([
    {
      path: "/",
      element: <MainLayout />,
      children: [
        { path: "", element: <Main /> },
        { path: "todo", element: <TaskMain /> },
      ],
    },
  ]);

  return <RouterProvider router={routers} />;
};
export default RouterAppProvider;
